-- ===============================================================================================================================================================================================
-- author:			�ukasz D�browski
-- project:			DABROWSKI SOFTWARE DEVELOPMENT
-- www:				https://github.com/Dabrowski-Software-Development?tab=repositories
-- creation date:	2016-04-12
-- description:		Returns T-SQL SELECT query based on provided parameters and C# class for storing data of the result of this query. Parameters are self-explaining.
--					Future version will cover VB.NET class.
-- version:			1.0.0
-- license:			MIT (http://www.opensource.org/licenses/mit-license.php)
-- feedback:		contact@lukaszdabrowski.com
-- ===============================================================================================================================================================================================

IF OBJECT_ID('CREATE_SELECT_QUERY_AND_DATA_HOLDER_CLASS') IS NOT NULL
 DROP FUNCTION CREATE_SELECT_QUERY_AND_DATA_HOLDER_CLASS
GO

CREATE FUNCTION CREATE_SELECT_QUERY_AND_DATA_HOLDER_CLASS
(
 @P_TABLE_NAME AS VARCHAR(MAX),
 @P_WHERE_CLAUSE_CONDITION AS VARCHAR(MAX) = '',
 @P_TABLE_NAME_ALIAS AS VARCHAR(MAX) = 'TA',
 @P_ISNULL_DATABASE_KEAYWORD AS VARCHAR(MAX) = 'ISNULL',
 @P_APPLY_TRIMMING AS BIT = 0,
 @P_ORDINAL_POSITION_START AS INT = -1,
 @P_ORDINAL_POSITION_END AS INT = -1,
 @P_COLUMN_ORDINAL_POSITION_LIST_TO_EXCLUDE AS VARCHAR(MAX) = '',
 @P_CREATE_CLASS_PROPERTIES AS BIT = 1,
 @P_CLASS_NAME_IS_BASED_ON_TABLE_NAME AS BIT = 1,
 @P_CLASS_NAME AS VARCHAR(MAX) = ''
)
RETURNS @RESULT_TABLE TABLE(DATA NVARCHAR(MAX))
AS
 BEGIN
	DECLARE @SELECT_QUERY AS VARCHAR(MAX) = 'SELECT '
	DECLARE @PROGRAMMING_LANGUAGE_CLASS AS VARCHAR(MAX) = ''
	DECLARE @ENTER AS CHAR(2) = CHAR(13)+CHAR(10)
	
	--apply trimming to all passed parameters
	SET @P_TABLE_NAME = LTRIM(RTRIM(@P_TABLE_NAME))
	SET @P_WHERE_CLAUSE_CONDITION = LTRIM(RTRIM(@P_WHERE_CLAUSE_CONDITION))
	SET @P_TABLE_NAME_ALIAS = LTRIM(RTRIM(@P_TABLE_NAME_ALIAS))
	SET @P_ISNULL_DATABASE_KEAYWORD = LTRIM(RTRIM(@P_ISNULL_DATABASE_KEAYWORD))
	SET @P_COLUMN_ORDINAL_POSITION_LIST_TO_EXCLUDE = LTRIM(RTRIM(@P_COLUMN_ORDINAL_POSITION_LIST_TO_EXCLUDE))
	SET @P_CLASS_NAME = LTRIM(RTRIM(@P_CLASS_NAME))
	
	
	IF RIGHT(@P_COLUMN_ORDINAL_POSITION_LIST_TO_EXCLUDE, 1) <> ','
	 SET @P_COLUMN_ORDINAL_POSITION_LIST_TO_EXCLUDE = @P_COLUMN_ORDINAL_POSITION_LIST_TO_EXCLUDE + ','
	
	IF @P_APPLY_TRIMMING = 1
	 BEGIN
		IF @P_ORDINAL_POSITION_START <> -1 AND @P_ORDINAL_POSITION_END <> -1
		 BEGIN
	 		SELECT @SELECT_QUERY = @SELECT_QUERY + @P_ISNULL_DATABASE_KEAYWORD + '(LTRIM(RTRIM(' + @P_TABLE_NAME_ALIAS + '.' + SC.COLUMN_NAME + ')), '''') AS ' + SC.COLUMN_NAME + ','
			FROM INFORMATION_SCHEMA.COLUMNS AS SC
			WHERE SC.TABLE_NAME = LTRIM(RTRIM(@P_TABLE_NAME))
			 AND SC.ORDINAL_POSITION >= @P_ORDINAL_POSITION_START AND SC.ORDINAL_POSITION <= @P_ORDINAL_POSITION_END
			 AND SC.ORDINAL_POSITION NOT IN (
			  SELECT CAST(CT.CUSTOM_COLUMN AS INT) AS CUSTOM_COLUMN
			  FROM DBO.CREATE_CUSTOM_TABLE(@P_COLUMN_ORDINAL_POSITION_LIST_TO_EXCLUDE, ',', '', 0,0) AS CT
			 )
			ORDER BY SC.ORDINAL_POSITION
		 END
		ELSE
		 BEGIN
	 		SELECT @SELECT_QUERY = @SELECT_QUERY + @P_ISNULL_DATABASE_KEAYWORD + '(LTRIM(RTRIM(' + @P_TABLE_NAME_ALIAS + '.' + SC.COLUMN_NAME + ')), '''') AS ' + SC.COLUMN_NAME + ','
			FROM INFORMATION_SCHEMA.COLUMNS AS SC
			WHERE SC.TABLE_NAME = LTRIM(RTRIM(@P_TABLE_NAME))
			ORDER BY SC.ORDINAL_POSITION
		 END
	 END
	ELSE
	 BEGIN
		IF @P_ORDINAL_POSITION_START <> -1 AND @P_ORDINAL_POSITION_END <> -1
		 BEGIN
	 		SELECT @SELECT_QUERY = @SELECT_QUERY + @P_ISNULL_DATABASE_KEAYWORD + '(' + @P_TABLE_NAME_ALIAS + '.' + SC.COLUMN_NAME + ', '''') AS ' + SC.COLUMN_NAME + ','
			FROM INFORMATION_SCHEMA.COLUMNS AS SC
			WHERE SC.TABLE_NAME = LTRIM(RTRIM(@P_TABLE_NAME))
			 AND SC.ORDINAL_POSITION >= @P_ORDINAL_POSITION_START AND SC.ORDINAL_POSITION <= @P_ORDINAL_POSITION_END
			 AND SC.ORDINAL_POSITION NOT IN (
			  SELECT CAST(CT.CUSTOM_COLUMN AS INT) AS CUSTOM_COLUMN
			  FROM DBO.CREATE_CUSTOM_TABLE(@P_COLUMN_ORDINAL_POSITION_LIST_TO_EXCLUDE, ',', '', 0,0) AS CT
			 )	 
			ORDER BY SC.ORDINAL_POSITION
		 END
		ELSE
		 BEGIN
	 		SELECT @SELECT_QUERY = @SELECT_QUERY + @P_ISNULL_DATABASE_KEAYWORD + '(' + @P_TABLE_NAME_ALIAS + '.' + SC.COLUMN_NAME + ', '''') AS ' + SC.COLUMN_NAME + ','
			FROM INFORMATION_SCHEMA.COLUMNS AS SC
			WHERE SC.TABLE_NAME = LTRIM(RTRIM(@P_TABLE_NAME))
			ORDER BY SC.ORDINAL_POSITION
		 END	 
	 END
	
	SELECT @SELECT_QUERY = LEFT(@SELECT_QUERY, LEN(@SELECT_QUERY) -1)
	
	SELECT @SELECT_QUERY = @SELECT_QUERY + @ENTER + 'FROM ' + @P_TABLE_NAME + ' AS ' + @P_TABLE_NAME_ALIAS
	
	SET @P_WHERE_CLAUSE_CONDITION = LTRIM(RTRIM(@P_WHERE_CLAUSE_CONDITION))
	IF @P_WHERE_CLAUSE_CONDITION IS NOT NULL AND @P_WHERE_CLAUSE_CONDITION <> ''
	 BEGIN
		SELECT @SELECT_QUERY = @SELECT_QUERY + ' WHERE ' + REPLACE(' ' + @P_WHERE_CLAUSE_CONDITION, '.', ' ' + @P_TABLE_NAME_ALIAS + '.')
	 END
	IF @P_TABLE_NAME IS NULL OR @P_TABLE_NAME = ''
		INSERT @RESULT_TABLE(DATA) VALUES('INVALID QUERY BECAUSE TABLE NAME IS NULL OR EMPTY.')
	ELSE
		INSERT @RESULT_TABLE(DATA) VALUES(@SELECT_QUERY)
			
	IF @P_CREATE_CLASS_PROPERTIES = 1
	 BEGIN
	    IF @P_CLASS_NAME_IS_BASED_ON_TABLE_NAME = 1 AND (@P_TABLE_NAME IS NULL OR @P_TABLE_NAME = '')
	     BEGIN
			INSERT @RESULT_TABLE(DATA) VALUES('CLASS NAME MUST HAVE A NAME BASED ON TABLE NAME. PROVIDE TABLE NAME INSTEAD.')    
		 END
	    ELSE IF @P_CLASS_NAME_IS_BASED_ON_TABLE_NAME = 1 AND @P_TABLE_NAME IS NOT NULL AND @P_TABLE_NAME <> ''
	      BEGIN
			SET @PROGRAMMING_LANGUAGE_CLASS = @PROGRAMMING_LANGUAGE_CLASS + 'public class ' + dbo.CREATE_CLASS_PROPERTY_NAME_BASED_ON_COLUMN_NAME(ISNULL(@P_TABLE_NAME, '')) + ' { '
	 		SELECT @PROGRAMMING_LANGUAGE_CLASS = @PROGRAMMING_LANGUAGE_CLASS +
	 													 CASE
	 													  WHEN CAST(SC.DATA_TYPE AS VARCHAR(MAX)) = 'int'
	 													   THEN
	 														' public int ' + ISNULL(dbo.CREATE_CLASS_PROPERTY_NAME_BASED_ON_COLUMN_NAME(SC.COLUMN_NAME), '') + ' { get; set; }'
	 													  WHEN CAST(SC.DATA_TYPE AS VARCHAR(MAX)) = 'varchar'
	 													   THEN
	 														' public string ' + ISNULL(dbo.CREATE_CLASS_PROPERTY_NAME_BASED_ON_COLUMN_NAME(SC.COLUMN_NAME), '') + ' { get; set; }'
	 													  WHEN CAST(SC.DATA_TYPE AS VARCHAR(MAX)) = 'image'
	 													   THEN
	 														' public byte[] ' + ISNULL(dbo.CREATE_CLASS_PROPERTY_NAME_BASED_ON_COLUMN_NAME(SC.COLUMN_NAME), '') + ' { get; set; }'
	 													  WHEN CAST(SC.DATA_TYPE AS VARCHAR(MAX)) = 'money'
	 													   THEN
	 														' public decimal ' + ISNULL(dbo.CREATE_CLASS_PROPERTY_NAME_BASED_ON_COLUMN_NAME(SC.COLUMN_NAME), '') + ' { get; set; }'
	 													  WHEN CAST(SC.DATA_TYPE AS VARCHAR(MAX)) = 'decimal'
	 													   THEN
	 														' public decimal ' + ISNULL(dbo.CREATE_CLASS_PROPERTY_NAME_BASED_ON_COLUMN_NAME(SC.COLUMN_NAME), '') + ' { get; set; }'
	 													  WHEN CAST(SC.DATA_TYPE AS VARCHAR(MAX)) = 'timestamp'
	 													   THEN
	 														' public DateTime ' + ISNULL(dbo.CREATE_CLASS_PROPERTY_NAME_BASED_ON_COLUMN_NAME(SC.COLUMN_NAME), '') + ' { get; set; }'
	 													  WHEN CAST(SC.DATA_TYPE AS VARCHAR(MAX)) = 'varbinary'
	 													   THEN
	 														' public byte[] ' + ISNULL(dbo.CREATE_CLASS_PROPERTY_NAME_BASED_ON_COLUMN_NAME(SC.COLUMN_NAME), '') + ' { get; set; }'
	 													  WHEN CAST(SC.DATA_TYPE AS VARCHAR(MAX)) = 'text'
	 													   THEN
	 														' public string ' + ISNULL(dbo.CREATE_CLASS_PROPERTY_NAME_BASED_ON_COLUMN_NAME(SC.COLUMN_NAME), '') + ' { get; set; }'
	 													  WHEN CAST(SC.DATA_TYPE AS VARCHAR(MAX)) = 'smallint'
	 													   THEN
	 														' public short ' + ISNULL(dbo.CREATE_CLASS_PROPERTY_NAME_BASED_ON_COLUMN_NAME(SC.COLUMN_NAME), '') + ' { get; set; }'
	 													  WHEN CAST(SC.DATA_TYPE AS VARCHAR(MAX)) = 'binary'
	 													   THEN
	 														' public byte[] ' + ISNULL(dbo.CREATE_CLASS_PROPERTY_NAME_BASED_ON_COLUMN_NAME(SC.COLUMN_NAME), '') + ' { get; set; }'
	 													  WHEN CAST(SC.DATA_TYPE AS VARCHAR(MAX)) = 'datetime'
	 													   THEN
	 														' public DateTime ' + ISNULL(dbo.CREATE_CLASS_PROPERTY_NAME_BASED_ON_COLUMN_NAME(SC.COLUMN_NAME), '') + ' { get; set; }'
	 													  WHEN CAST(SC.DATA_TYPE AS VARCHAR(MAX)) = 'numeric'
	 													   THEN
	 														' public float ' + ISNULL(dbo.CREATE_CLASS_PROPERTY_NAME_BASED_ON_COLUMN_NAME(SC.COLUMN_NAME), '') + ' { get; set; }'
	 													  WHEN CAST(SC.DATA_TYPE AS VARCHAR(MAX)) = 'uniqueidentifier'
	 													   THEN
	 														' public Guid ' + ISNULL(dbo.CREATE_CLASS_PROPERTY_NAME_BASED_ON_COLUMN_NAME(SC.COLUMN_NAME), '') + ' { get; set; }'
	 													  WHEN CAST(SC.DATA_TYPE AS VARCHAR(MAX)) = 'tinyint'
	 													   THEN
	 														' public byte ' + ISNULL(dbo.CREATE_CLASS_PROPERTY_NAME_BASED_ON_COLUMN_NAME(SC.COLUMN_NAME), '') + ' { get; set; }'
	 													  WHEN CAST(SC.DATA_TYPE AS VARCHAR(MAX)) = 'nchar'
	 													   THEN
	 														' public char ' + ISNULL(dbo.CREATE_CLASS_PROPERTY_NAME_BASED_ON_COLUMN_NAME(SC.COLUMN_NAME), '') + ' { get; set; }'
	 													  WHEN CAST(SC.DATA_TYPE AS VARCHAR(MAX)) = 'float'
	 													   THEN
	 														' public float ' + ISNULL(dbo.CREATE_CLASS_PROPERTY_NAME_BASED_ON_COLUMN_NAME(SC.COLUMN_NAME), '') + ' { get; set; }'
	 													  WHEN CAST(SC.DATA_TYPE AS VARCHAR(MAX)) = 'char'
	 													   THEN
	 														' public char ' + ISNULL(dbo.CREATE_CLASS_PROPERTY_NAME_BASED_ON_COLUMN_NAME(SC.COLUMN_NAME), '') + ' { get; set; }'
	 													  WHEN CAST(SC.DATA_TYPE AS VARCHAR(MAX)) = 'real'
	 													   THEN
	 														' public float ' + ISNULL(dbo.CREATE_CLASS_PROPERTY_NAME_BASED_ON_COLUMN_NAME(SC.COLUMN_NAME), '') + ' { get; set; }'
	 													  WHEN CAST(SC.DATA_TYPE AS VARCHAR(MAX)) = 'bigint'
	 													   THEN
	 														' public long ' + ISNULL(dbo.CREATE_CLASS_PROPERTY_NAME_BASED_ON_COLUMN_NAME(SC.COLUMN_NAME), '') + ' { get; set; }'
	 													  WHEN CAST(SC.DATA_TYPE AS VARCHAR(MAX)) = 'ntext'
	 													   THEN
	 														' public string ' + ISNULL(dbo.CREATE_CLASS_PROPERTY_NAME_BASED_ON_COLUMN_NAME(SC.COLUMN_NAME), '') + ' { get; set; }'
	 													  WHEN CAST(SC.DATA_TYPE AS VARCHAR(MAX)) = 'nvarchar'
	 													   THEN
	 														' public string ' + ISNULL(dbo.CREATE_CLASS_PROPERTY_NAME_BASED_ON_COLUMN_NAME(SC.COLUMN_NAME), '') + ' { get; set; }'
	 													  WHEN CAST(SC.DATA_TYPE AS VARCHAR(MAX)) = 'bit'
	 													   THEN
	 														' public bool ' + ISNULL(dbo.CREATE_CLASS_PROPERTY_NAME_BASED_ON_COLUMN_NAME(SC.COLUMN_NAME), '') + ' { get; set; }'	 														
														  ELSE
														  ' public object ' + ISNULL(dbo.CREATE_CLASS_PROPERTY_NAME_BASED_ON_COLUMN_NAME(SC.COLUMN_NAME), '') + ' { get; set; }'
	 													 END
	 											 
			FROM INFORMATION_SCHEMA.COLUMNS AS SC
			WHERE SC.TABLE_NAME = LTRIM(RTRIM(@P_TABLE_NAME))
			ORDER BY SC.ORDINAL_POSITION	
			
			SET @PROGRAMMING_LANGUAGE_CLASS = @PROGRAMMING_LANGUAGE_CLASS + ' }'				
	      END
	     
	    ELSE IF @P_CLASS_NAME_IS_BASED_ON_TABLE_NAME = 0 AND (@P_CLASS_NAME IS NULL OR @P_CLASS_NAME = '')
	      BEGIN
			INSERT @RESULT_TABLE(DATA) VALUES('CLASS NAME MUST HAVE A NAME BASED ON ''@P_CLASS_NAME''. PROVIDE VALUE FOR PARAMETER INSTEAD.')	
	      END
	    ELSE IF @P_CLASS_NAME_IS_BASED_ON_TABLE_NAME = 0 AND @P_CLASS_NAME IS NOT NULL AND @P_CLASS_NAME <> ''
	      BEGIN
			SET @PROGRAMMING_LANGUAGE_CLASS = @PROGRAMMING_LANGUAGE_CLASS + 'public class ' + dbo.CREATE_CLASS_PROPERTY_NAME_BASED_ON_COLUMN_NAME(ISNULL(@P_CLASS_NAME, '')) + ' { '
	 		
	 		SELECT @PROGRAMMING_LANGUAGE_CLASS = @PROGRAMMING_LANGUAGE_CLASS +
	 													 CASE
	 													  WHEN CAST(SC.DATA_TYPE AS VARCHAR(MAX)) = 'int'
	 													   THEN
	 														' public int ' + ISNULL(dbo.CREATE_CLASS_PROPERTY_NAME_BASED_ON_COLUMN_NAME(SC.COLUMN_NAME), '') + ' { get; set; }'
	 													  WHEN CAST(SC.DATA_TYPE AS VARCHAR(MAX)) = 'varchar'
	 													   THEN
	 														' public string ' + ISNULL(dbo.CREATE_CLASS_PROPERTY_NAME_BASED_ON_COLUMN_NAME(SC.COLUMN_NAME), '') + ' { get; set; }'
	 													  WHEN CAST(SC.DATA_TYPE AS VARCHAR(MAX)) = 'image'
	 													   THEN
	 														' public byte[] ' + ISNULL(dbo.CREATE_CLASS_PROPERTY_NAME_BASED_ON_COLUMN_NAME(SC.COLUMN_NAME), '') + ' { get; set; }'
	 													  WHEN CAST(SC.DATA_TYPE AS VARCHAR(MAX)) = 'money'
	 													   THEN
	 														' public decimal ' + ISNULL(dbo.CREATE_CLASS_PROPERTY_NAME_BASED_ON_COLUMN_NAME(SC.COLUMN_NAME), '') + ' { get; set; }'
	 													  WHEN CAST(SC.DATA_TYPE AS VARCHAR(MAX)) = 'decimal'
	 													   THEN
	 														' public decimal ' + ISNULL(dbo.CREATE_CLASS_PROPERTY_NAME_BASED_ON_COLUMN_NAME(SC.COLUMN_NAME), '') + ' { get; set; }'
	 													  WHEN CAST(SC.DATA_TYPE AS VARCHAR(MAX)) = 'timestamp'
	 													   THEN
	 														' public DateTime ' + ISNULL(dbo.CREATE_CLASS_PROPERTY_NAME_BASED_ON_COLUMN_NAME(SC.COLUMN_NAME), '') + ' { get; set; }'
	 													  WHEN CAST(SC.DATA_TYPE AS VARCHAR(MAX)) = 'varbinary'
	 													   THEN
	 														' public byte[] ' + ISNULL(dbo.CREATE_CLASS_PROPERTY_NAME_BASED_ON_COLUMN_NAME(SC.COLUMN_NAME), '') + ' { get; set; }'
	 													  WHEN CAST(SC.DATA_TYPE AS VARCHAR(MAX)) = 'text'
	 													   THEN
	 														' public string ' + ISNULL(dbo.CREATE_CLASS_PROPERTY_NAME_BASED_ON_COLUMN_NAME(SC.COLUMN_NAME), '') + ' { get; set; }'
	 													  WHEN CAST(SC.DATA_TYPE AS VARCHAR(MAX)) = 'smallint'
	 													   THEN
	 														' public short ' + ISNULL(dbo.CREATE_CLASS_PROPERTY_NAME_BASED_ON_COLUMN_NAME(SC.COLUMN_NAME), '') + ' { get; set; }'
	 													  WHEN CAST(SC.DATA_TYPE AS VARCHAR(MAX)) = 'binary'
	 													   THEN
	 														' public byte[] ' + ISNULL(dbo.CREATE_CLASS_PROPERTY_NAME_BASED_ON_COLUMN_NAME(SC.COLUMN_NAME), '') + ' { get; set; }'
	 													  WHEN CAST(SC.DATA_TYPE AS VARCHAR(MAX)) = 'datetime'
	 													   THEN
	 														' public DateTime ' + ISNULL(dbo.CREATE_CLASS_PROPERTY_NAME_BASED_ON_COLUMN_NAME(SC.COLUMN_NAME), '') + ' { get; set; }'
	 													  WHEN CAST(SC.DATA_TYPE AS VARCHAR(MAX)) = 'numeric'
	 													   THEN
	 														' public float ' + ISNULL(dbo.CREATE_CLASS_PROPERTY_NAME_BASED_ON_COLUMN_NAME(SC.COLUMN_NAME), '') + ' { get; set; }'
	 													  WHEN CAST(SC.DATA_TYPE AS VARCHAR(MAX)) = 'uniqueidentifier'
	 													   THEN
	 														' public Guid ' + ISNULL(dbo.CREATE_CLASS_PROPERTY_NAME_BASED_ON_COLUMN_NAME(SC.COLUMN_NAME), '') + ' { get; set; }'
	 													  WHEN CAST(SC.DATA_TYPE AS VARCHAR(MAX)) = 'tinyint'
	 													   THEN
	 														' public byte ' + ISNULL(dbo.CREATE_CLASS_PROPERTY_NAME_BASED_ON_COLUMN_NAME(SC.COLUMN_NAME), '') + ' { get; set; }'
	 													  WHEN CAST(SC.DATA_TYPE AS VARCHAR(MAX)) = 'nchar'
	 													   THEN
	 														' public char ' + ISNULL(dbo.CREATE_CLASS_PROPERTY_NAME_BASED_ON_COLUMN_NAME(SC.COLUMN_NAME), '') + ' { get; set; }'
	 													  WHEN CAST(SC.DATA_TYPE AS VARCHAR(MAX)) = 'float'
	 													   THEN
	 														' public float ' + ISNULL(dbo.CREATE_CLASS_PROPERTY_NAME_BASED_ON_COLUMN_NAME(SC.COLUMN_NAME), '') + ' { get; set; }'
	 													  WHEN CAST(SC.DATA_TYPE AS VARCHAR(MAX)) = 'char'
	 													   THEN
	 														' public char ' + ISNULL(dbo.CREATE_CLASS_PROPERTY_NAME_BASED_ON_COLUMN_NAME(SC.COLUMN_NAME), '') + ' { get; set; }'
	 													  WHEN CAST(SC.DATA_TYPE AS VARCHAR(MAX)) = 'real'
	 													   THEN
	 														' public float ' + ISNULL(dbo.CREATE_CLASS_PROPERTY_NAME_BASED_ON_COLUMN_NAME(SC.COLUMN_NAME), '') + ' { get; set; }'
	 													  WHEN CAST(SC.DATA_TYPE AS VARCHAR(MAX)) = 'bigint'
	 													   THEN
	 														' public long ' + ISNULL(dbo.CREATE_CLASS_PROPERTY_NAME_BASED_ON_COLUMN_NAME(SC.COLUMN_NAME), '') + ' { get; set; }'
	 													  WHEN CAST(SC.DATA_TYPE AS VARCHAR(MAX)) = 'ntext'
	 													   THEN
	 														' public string ' + ISNULL(dbo.CREATE_CLASS_PROPERTY_NAME_BASED_ON_COLUMN_NAME(SC.COLUMN_NAME), '') + ' { get; set; }'
	 													  WHEN CAST(SC.DATA_TYPE AS VARCHAR(MAX)) = 'nvarchar'
	 													   THEN
	 														' public string ' + ISNULL(dbo.CREATE_CLASS_PROPERTY_NAME_BASED_ON_COLUMN_NAME(SC.COLUMN_NAME), '') + ' { get; set; }'
	 													  WHEN CAST(SC.DATA_TYPE AS VARCHAR(MAX)) = 'bit'
	 													   THEN
	 														' public bool ' + ISNULL(dbo.CREATE_CLASS_PROPERTY_NAME_BASED_ON_COLUMN_NAME(SC.COLUMN_NAME), '') + ' { get; set; }'	 														
														  ELSE
														  ' public object ' + ISNULL(dbo.CREATE_CLASS_PROPERTY_NAME_BASED_ON_COLUMN_NAME(SC.COLUMN_NAME), '') + ' { get; set; }'
	 													 END
	 											 
			FROM INFORMATION_SCHEMA.COLUMNS AS SC
			WHERE SC.TABLE_NAME = LTRIM(RTRIM(@P_TABLE_NAME))
			ORDER BY SC.ORDINAL_POSITION	
			
			SET @PROGRAMMING_LANGUAGE_CLASS = @PROGRAMMING_LANGUAGE_CLASS + ' }'
	      END
	  INSERT @RESULT_TABLE(DATA) VALUES(@PROGRAMMING_LANGUAGE_CLASS)	      
	 END
				
	RETURN
 END
 