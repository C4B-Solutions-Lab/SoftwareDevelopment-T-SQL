-- =============================================================================================================================================================================================================================
-- author:				�ukasz D�browski
-- project:				DABROWSKI SOFTWARE DEVELOPMENT
-- www:					https://github.com/Dabrowski-Software-Development?tab=repositories, coming soon: https://dabrowski-software-development.github.io/
-- creation date:		2016-12-11
-- modification date:	2017-01-17
-- description:		    Converts JSON collection to a table. Support for SQL SERVER versions prior to SQL SERVER 2016.
--
--[INFO]:
--						This version runs against persistent tables.

--						"null" values in JSON object are converted to ___NULL___ literal. It is end user's responsibility to handle this value appropriately.
--						Date & time values are handled as in T-SQL, datetime value have to be separated with uppercase T letter, i.e. "2016-05-14T22:29:34"
--
--						This procedure depends on the following functions, which are included in this solution in the file called [T-SQL_UTILITY_FUNCTIONS_INSTALL.sql]
--													dbo.TRIM_SPACE_ENTER_TAB,
--													dbo.SUBSTRING2,
--													dbo.GET_COLUMN_TYPE_BASED_ON_DATA_TYPE,
--													dbo.DO_REPLACE,
--													dbo.REMOVE_ALL_CHARS_FROM_STRING_EXCEPT_FOR_EXPLICITLY_PROVIDED
--
--						and the following procedures, which are included in this solution in the file called [JSON2SQL_T-SQL_UTILITY_PROCEDURES_INSTALL].sql
--													dbo.JSON2SQL_1_VALIDATE_JSON_COLLECTION,
--													dbo.JSON2SQL_2_VALIDATE_JSON_COLLECTION_OBJECT_LAYOUT___fill_in___JSON_OBJECT_LAYOUT_TABLE_COLLECTION,
--													dbo.JSON2SQL_3_CREATE_INSERT_SELECT_TEMPLATE___fill_in___JSON_OBJECT_LAYOUT_TABLE_COLLECTION,
--													dbo.JSON2SQL_4_CALCULATE___PROP_NAME___PROP_VALUE___OBJECT_NUMBER___NESTING_LEVEL___fill_in___JSON_ITEM_COLLECTION_TO_TABLE_INTERNAL,
--													dbo.JSON2SQL_5_DO_INTERNAL_ORDERING___fill_in___JSON_ITEM_COLLECTION_TO_TABLE_INTERNAL_2,
--													dbo.JSON2SQL_6_DO_INTERNAL_ORDERING_2___fill_in___NUMBER_OF_PROPERTIES_PER_EACH_OBJECT,
--													dbo.JSON2SQL_7_DO_INTERNAL_ORDERING_3___fill_in___JSON_ITEM_COLLECTION_TO_TABLE_INTERNAL_3,
--													dbo.JSON2SQL_8_VALIDATE_JSON_COLLECTION_NAMES_OF_PROPERTIES,
--													dbo.JSON2SQL_9_DO_BULK_INSERT,
--													dbo.JSON2SQL_RAISE_ERROR
--
--			            Due to implementation details of handling null values [___NULL___],
--						columns of type CHAR, NCHAR, VARCHAR and NVARCHAR that have null values in JSON object have to have column size of at least 10 characters.
--
--						This version recognizes collection of complex JSON objects, where each item can be valid JSON object of ANY STRUCTURE supported by this version.
--						Level of nested JSON objects is unlimited.
--
--						1. ALLOWING FOR OBJECT TABLE REPRESENTATION HAVING ONE COLUMN
--
--						2. THIS VERSION RUNS AGAINST PERSISTENT TABLES WHICH GUARANTEES 100% ACCURACY OF THE OUTPUT. SUCH A DECISION WAS MADE BASED ON VARIOUS TESTING SCENARIOS,
--						   WHICH FOR TEMPORATY TABLES GENERATED SOME UNPREDICTABLE OUTPUTS IN SOME CASES IN THE EARLY STAGES OF THE ALGORITHM.
--
--						3. COMPLEX CHILD OBJECTS WITH DIFFERENT NUMBER OF COLUMNS.
--						   2+ complex objects under MAIN JSON object with THE SAME NESTING LEVEL can have DIFFERENT NUMBER of columns
--
--
--[VERSION]:			1.8.0
--
--
--[CHANGES]:
--						This version recognizes collection of complex JSON objects, where each item can be valid JSON object of ANY STRUCTURE.
--						IMPROVEMENTS over the previous version are:
--							
--							1. the ability to define f.e. two child objects under given parent object, where each of them can have f.e. different number of properties on the same nesting level.
--
--							2. improved validation of input parameters in terms of execution time
--
--							3. improved validation of JSON collection in terms of amount of written code, speed & meaningful error information
--
--							4. improved number of scans and logical iterations over intermediate tables
--
--							5. addition of appropriate covering indexes
--
--							6. insertion of new rows into target tables implemented as "CLUSTERED INDEX INSERT" - new rows are being added to the end of current data page
--
--							7. this version is split into different modules conforming to the following development rules: SRP, DRY, KISS
--
--							8. this version is the most general one of all available, modularized and the fastest one 
--							   due to much simplefied overall logic which resulted in less written code
--
--						Level of nested JSON objects is unlimited.
--
--
--
--[INPUT PARAMETERS]:
--
--						@P_JSON_COLLECTION_OBJECT_LAYOUT 
--																	-> Names of tables in ASC order for each level respectively (names ONLY). Below is a table definition pseudocode i.e.
--																	   Based on the example provided in this solution configuration for this parameter is given below:
/*
										 MY_ROOT_TABLE,
										 MY_SUB_TABLE_1_1,MY_SUB_TABLE_1_2			,MY_SUB_TABLE_1_3,
										 |,
										 MY_SUB_TABLE_2_1,___MISSING_LEVEL_OBJECT___,___MISSING_LEVEL_OBJECT___,
										 |,
										 MY_SUB_TABLE_3_1,MY_SUB_TABLE_3_2			,MY_SUB_TABLE_3_3,
										 |,
										 MY_SUB_TABLE_4_1,MY_SUB_TABLE_4_2			,___MISSING_LEVEL_OBJECT___

*/
--						Explanation:
/*
								MY_ROOT_TABLE - root table containing top level JSON object's properties

								MY_SUB_TABLE_1_1,MY_SUB_TABLE_1_2			,MY_SUB_TABLE_1_3, - comma separated tables containing FIRST complex child JSON object's each level properties respectively (level 2, 3, 4)
								
								| - reserved character that acts as a separator among multiple complex child JSON objects
								
								MY_SUB_TABLE_2_1,___MISSING_LEVEL_OBJECT___,___MISSING_LEVEL_OBJECT___ - comma separated tables containing SECOND complex child JSON object's each level properties respectively (level 2, 3, 4)
								
								MY_SUB_TABLE_3_1,MY_SUB_TABLE_3_2			,MY_SUB_TABLE_3_3 - comma separated tables containing THIRD complex child JSON object's each level properties respectively (level 2, 3, 4)
								
								MY_SUB_TABLE_4_1,MY_SUB_TABLE_4_2			,___MISSING_LEVEL_OBJECT___ - comma separated tables containing FOURTH complex child JSON object's each level properties respectively (level 2, 3, 4)
								
								___MISSING_LEVEL_OBJECT___ - reserved literal telling that current complex child JSON object is missing particular nesting level's data
*/ 
--						@P_JSON_COLLECTION
--									-> Collection of complex JSON objects
--
--						THIS VERSION DOES NOT recognize nesting collection ( [...] ) of JSON objects inside a single object YET.
--						This is the EXTENDED VERSION of CONVERT_JSON_OBJECT_TO_SQL_TABLE_3 procedure. It is built upon that procedure WITH SOME ENHANCEMENTS.
--
--		 _________________________________________________________________________________________________________________________________________________________________________________________________
--		|																																																  |
--		|			IN SHORT, THIS VERSION IS THE REPLACEMENT OF [v1], [v2] & [v3]																														  |
--		|			with addition of allowing multiple nesting levels of different complex objects being of different size.																				  |
--		|																																																  |										
--		|_________________________________________________________________________________________________________________________________________________________________________________________________|
--
--
--
--[WARNING]:	
--					
--						IF @P_JSON_COLLECTION_OBJECT_LAYOUT HAS CONFIGURATION LIKE BELOW:

/*
										 MY_ROOT_TABLE,
										 MY_SUB_TABLE_1_1,MY_SUB_TABLE_1_2			,MY_SUB_TABLE_1_3,___MISSING_LEVEL_OBJECT___,
										 |,
										 MY_SUB_TABLE_2_1,___MISSING_LEVEL_OBJECT___,___MISSING_LEVEL_OBJECT___,___MISSING_LEVEL_OBJECT___,
										 |,
										 MY_SUB_TABLE_3_1,MY_SUB_TABLE_3_2			,MY_SUB_TABLE_3_3,___MISSING_LEVEL_OBJECT___,
										 |,
										 MY_SUB_TABLE_4_1,MY_SUB_TABLE_4_2			,___MISSING_LEVEL_OBJECT___,___MISSING_LEVEL_OBJECT___


						THEN THERE IS CLEAR THAT JSON COLLECTION HAS ONLY 3 NESTED LEVELS STARTING FROM ROOT LEVEL AND 4TH NESTED LEVEL DOES NOT EXIST IN ANY COMPLEX OBJECT,
						THEN ALGORITHM WILL RUN INDEFINITELY. THERE IS NO SUCH CHECKING DUE TO PERFORMANCE ISSUE.
						CONFIGURATION HAS TO MATCH THE STRUCTURE OF JSON MAIN OBJECT IN THE COLLECTION.

*/
--
--[LIMITATIONS]:
--
--						THERE ARE TWO LIMITATIONS REGARDING THIS VERSION OF ALGORITHM:
--						1. collection of complex any-structured JSON objects with any complex JSON object being of different size (number of complex properties) is NOT ALLOWED.
--						   ALLOWING FOR THE ABOVE IS PUT INTO CONSIDERATION!
--
--						2. complex object under main JSON object having 1 column and another complex object(s) has to adhere to 1 RULE, i.e. this "1 column" has to be put first and then complex object, e.g.
--											  a. below example WILL WORK
/*										    
												"complex_two": {
													"property_one": "3-1",
													"complex_three": {
														"property_one": "4-1",
														"property_one": "4-2",
														"property_one": "4-3"
													}
												}							
*/
--											  b. below example WILL FAIL
/*										    
												"complex_two": {
													"complex_three": {
														"property_one": "4-1",
														"property_one": "4-2",
														"property_one": "4-3"
													},
													"property_one": "3-1"
												}
*/
--
--
--[JOIN METHODOLOGY]:
--						In order to join tables provided as comma separated string (to get one row for each JSON object),
--						there is a requiremment to join all these tables using _TABLE_INTERNAL_PK_ column, which is generated internally.
--						Therefore this column name _TABLE_INTERNAL_PK_ is a reserved one and any table cannot contain column with such name.
--						ADDITIONALLY EVERY TABLE CANNOT HAVE PRIMARY KEY DEFINED ON ANY OF ITS COLUMNS AS WELL AS CLUSTERED INDEX WHICH IS DEFINED ON PRIMARY KEY COLUMN TOO.
--						THIS IS TO SPEED UP INITIAL PERFORMANCE.
--						Therefore this column _TABLE_INTERNAL_PK_ is defined as PRIMARY KEY CLUSTERED and should not be changed.
--						First table containing such column name will raise an error.
--
--
--[VALIDATION RULES]:
--						This version includes property names validation (duplicate names detection) per deepest complex object.
--						Every complex object on given nesting level has to have unique property names, e.g.
--					
--							first example below passes validation:
/*
								"complex_subObject_level_one": {
									"property_one": "11",
									"property_two": "111",
									"property_three": "THIS",
									"property_four": "1001",
									"1_complex_subObject_level_two": {
										"property_one": "a",
										"property_two": "b",
										"property_three": "a+b",
										"property_four": "a+b+1",
										"1_complex_subObject_level_three": {
											"property_one": "sss_1",
											"property_two": "sss_2",
											"property_three": "sss_3"
										}
									},
									"property_five": "#",
									"property_six": "$",
									"property_seven": "*"
								}

							whereas second example does not:

								"complex_subObject_level_one": {
									"property_one": "11",
									"property_two": "111",
									"property_three": "THIS",
									"property_four": "1001",
									"1_complex_subObject_level_two": {
										"property_one": "a",
										"property_two": "b",
										"property_three": "a+b",
										"property_four": "a+b+1",
										"1_complex_subObject_level_three": {
											"property_one": "sss_1",
											"property_two": "sss_2",
											"property_three": "sss_3"
										}
									},
									"property_five": "#",
									"property_one": "$",     <---  duplicated name detected
									"property_seven": "*"
								}
*/ 
--
--                  
--[EXAMPLE USAGE]:
--						Please refer to README.txt file provided with this solution for further details.
--
--
-- license:				MIT (http://www.opensource.org/licenses/mit-license.php)
-- feedback:			lukkasz.dabrowski@gmail.com
-- =============================================================================================================================================================================================================================

/* SET CURRENT DATABASE CONTEXT */
 USE $(UseDatabase)
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


CREATE PROCEDURE CONVERT_JSON_OBJECT_TO_SQL_TABLE_4_P
(
 @P_JSON_COLLECTION_OBJECT_LAYOUT AS NVARCHAR(MAX),
 @P_JSON_COLLECTION AS NVARCHAR(MAX)
)
AS
BEGIN
	   SET NOCOUNT ON
	   
	   /* SET UP INITIAL VARIABLES */
	   DECLARE
		@ERROR_TEMPLATE AS NVARCHAR(MAX) = N'',
		@SEPARATOR AS CHAR = '|',
		@MISSING_LEVEL_OBJECT AS CHAR(26) = '___MISSING_LEVEL_OBJECT___',
		@EMPTY_STRING AS VARCHAR = '',
		@TABULATOR AS CHAR(1) = CHAR(9),
		@ENTER AS CHAR(2) = CHAR(13)+CHAR(10),
		@JSON_OBJECT_COMPLEX_PROPERTY_LAST_INDEX AS INT = -1,
		@JSON_OBJECT_COMPLEX_PROPERTY_SEPARATOR_INDEX AS INT = -1,
		@JSON_OBJECT_COMPLEX_PROPERTY_COUNTER AS INT = 0,
		@JSON_OBJECT_COMPLEX_PROPERTIES_SEPARATOR_LAST_INDEX AS INT = -1, /* @SEPARATOR AS CHAR(1) = '|' */
		@BREAK_LOOP AS BIT = 0,
		@ALGORITHM_RUNS_AGAINST_TEMPORARY_TABLES AS BIT = 0



	   /* [ CORE PROCESSING - PART 0.1 ] VALIDATE JSON COLLECTION */
	   DECLARE
		@COMMA AS CHAR = CHAR(44),
		@NULL_CONSTANT AS CHAR(10) = '___NULL___',
		@RETURN_RESULT AS BIT
		
	   EXECUTE dbo.JSON2SQL_1_VALIDATE_JSON_COLLECTION
									@EMPTY_STRING,
									@COMMA,
									@ERROR_TEMPLATE,
									@P_JSON_COLLECTION OUTPUT,
									@RETURN_RESULT OUTPUT

	   IF @RETURN_RESULT = 0
	    RETURN


		
		/* [ CORE PROCESSING - PART 0.5 ] VALIDATE NAMES OF TABLES */
		DECLARE
			@VALIDATION_INDEX_START AS INT = 1,
			@VALIDATION_INDEX_END AS INT = -1,
			@TABLE_NAME AS NVARCHAR(MAX) = N'' + @EMPTY_STRING

		/* CREATE TEMPORAY TABLE TO STORE JSON OBJECT LAYOUT */
		CREATE TABLE #JSON_OBJECT_LAYOUT_TABLE_COLLECTION
		(
			ID INT NOT NULL,
			TABLE_NAME NVARCHAR(MAX),
			INSERT_SELECT_TEMPLATE_HEADER NVARCHAR(MAX), --STORES [INSERT SELECT TEMPLATE] FOR EACH OBJECT LAYOUT TABLE
			INSERT_SELECT_DATA_ROW NVARCHAR(MAX) --STORES [INSERT SELECT DATA ROW] FOR EACH OBJECT LAYOUT TABLE
		)

		EXECUTE dbo.JSON2SQL_2_VALIDATE_JSON_COLLECTION_OBJECT_LAYOUT___fill_in___JSON_OBJECT_LAYOUT_TABLE_COLLECTION -- (ID, TABLE_NAME)
												@P_JSON_COLLECTION_OBJECT_LAYOUT,
												@COMMA,
												@EMPTY_STRING,
												@TABLE_NAME,
												@SEPARATOR,
												@MISSING_LEVEL_OBJECT,
												@ERROR_TEMPLATE,
												@VALIDATION_INDEX_END OUTPUT,
												@RETURN_RESULT OUTPUT

	   IF @RETURN_RESULT = 0
	    RETURN



		/* [ CORE PROCESSING - PART 1 ] CREATE INSERT SELECT TEMPLATE */
		DECLARE
			@PROPERTY_VALUE AS NVARCHAR(MAX) = N''

		EXECUTE dbo.JSON2SQL_3_CREATE_INSERT_SELECT_TEMPLATE___fill_in___JSON_OBJECT_LAYOUT_TABLE_COLLECTION -- (INSERT_SELECT_TEMPLATE_HEADER, INSERT_SELECT_DATA_ROW)
											@EMPTY_STRING,
											@MISSING_LEVEL_OBJECT,
											@SEPARATOR,
											@ENTER,
											@ERROR_TEMPLATE,
											@VALIDATION_INDEX_START,
											@VALIDATION_INDEX_END,
											@TABLE_NAME,
											@ALGORITHM_RUNS_AGAINST_TEMPORARY_TABLES,
											@RETURN_RESULT OUTPUT

	   IF @RETURN_RESULT = 0
	    RETURN



		/* [ CORE PROCESSING - PART 2 ] CONVERT JSON COLLECTION TO ORDERED TABLE ROW REPRESENTATION (PROPERTY, VALUE, OBJECT NUMBER, NESTING LEVEL, OBJECT PROPERTY INDEX) */
		DECLARE
		 @INDEX_START_POSITION AS INT = 1,
		 @INDEX_END_POSITION AS INT = -1
		 		
		CREATE TABLE #JSON_ITEM_COLLECTION_TO_TABLE_INTERNAL
		(
			ID INT NOT NULL,
			JSON_ITEM NVARCHAR(MAX),
			PROPERTY_NAME NVARCHAR(MAX),
			PROPERTY_VALUE NVARCHAR(MAX),
			NESTING_LEVEL BIGINT,
			OBJECT_NUMBER BIGINT
		)

		/* CALCULATE PROPERTY NAME, PROPERTY VALUE, OBJECT NUMBER AND NESTING LEVEL */
		EXECUTE dbo.JSON2SQL_4_CALCULATE___PROP_NAME___PROP_VALUE___OBJECT_NUMBER___NESTING_LEVEL___fill_in___JSON_ITEM_COLLECTION_TO_TABLE_INTERNAL
																																@P_JSON_COLLECTION,
																																@INDEX_START_POSITION,
																																@COMMA,
																																@INDEX_END_POSITION OUTPUT



		/* [ CORE PROCESSING - PART 3 ] ORDER COLLECTION TO BE IN LINE WITH INPUT PARAMETER (first object's first property, second property, etc...) */
		CREATE TABLE #JSON_ITEM_COLLECTION_TO_TABLE_INTERNAL_2
		(
			ID INT IDENTITY NOT NULL,
			PROPERTY_NAME NVARCHAR(MAX),
			PROPERTY_VALUE NVARCHAR(MAX),
			NESTING_LEVEL BIGINT,
			OBJECT_NUMBER BIGINT,
			CURRENT_OBJECT_PROPERTY_INDEX BIGINT
		)

		EXECUTE dbo.JSON2SQL_5_DO_INTERNAL_ORDERING___fill_in___JSON_ITEM_COLLECTION_TO_TABLE_INTERNAL_2



		/* [ CORE PROCESSING - PART 4 ] ADD INTERNAL ORDERING TO ALREADY ORDERED COLLECTION SO THAT ORDERING OF PROPERTIES OF EVERY COMPLEX OBJECT MATCHES 1-1 RESPECTIVE TABLES' COLUMNS ORDINAL POSITION */
		DECLARE
			@INTERNAL_ORDERING_START AS INT = 1,
			@INTERNAL_ORDERING_STOP AS INT = -1,
			@JSON_OBJECT_MAX_NUMBER AS INT = -1
		
		/* CREATE TABLE HOLDING METADATA ABOUT SINGLE MAIN COMPLEX OBJECT IN THE JSON COLLECTION */
		CREATE TABLE #NUMBER_OF_PROPERTIES_PER_EACH_OBJECT
		(
			ID INT IDENTITY NOT NULL,
			NUMBER_OF_PROPERTIES INT,
			TABLE_NAME NVARCHAR(MAX)
		)

		EXECUTE dbo.JSON2SQL_6_DO_INTERNAL_ORDERING_2___fill_in___NUMBER_OF_PROPERTIES_PER_EACH_OBJECT
																					@SEPARATOR,
																					@INTERNAL_ORDERING_START,
																					@MISSING_LEVEL_OBJECT,
																					@INTERNAL_ORDERING_STOP OUTPUT



		/* [ CORE PROCESSING - PART 5 ] CREATE TABLE THAT WILL ALLOW TO PERFORM "CLUSTERED INDEX INSERT" TYPE OF OPERATION ALLOWING TO ADD NEW DATA ALWAYS TO THE END OF THE CURRENT DATA PAGE */
		CREATE TABLE #JSON_ITEM_COLLECTION_TO_TABLE_INTERNAL_3
		(
			ID INT IDENTITY NOT NULL,
			OBJECT_NUMBER BIGINT,
			NESTING_LEVEL BIGINT,
			PROPERTY_NAME NVARCHAR(MAX),
			PROPERTY_VALUE NVARCHAR(MAX),
			CURRENT_OBJECT_PROPERTY_INDEX BIGINT
		)

		EXECUTE dbo.JSON2SQL_7_DO_INTERNAL_ORDERING_3___fill_in___JSON_ITEM_COLLECTION_TO_TABLE_INTERNAL_3
																					@INTERNAL_ORDERING_START,
																					@INTERNAL_ORDERING_STOP



		/* [ CORE PROCESSING - PART 6 ] PERFORM VALIDATION OF PROPERTIES (each nesting level has to have unique names of properties in the context of nearest complex object)

		   Check http://jsonlint.com/ [JSONLint - The JSON Validator]) 
		*/

		EXECUTE dbo.JSON2SQL_8_VALIDATE_JSON_COLLECTION_NAMES_OF_PROPERTIES	
											@INDEX_START_POSITION,
											@INDEX_END_POSITION,
											@ENTER,
											@SEPARATOR,
											@MISSING_LEVEL_OBJECT,
											@ERROR_TEMPLATE,
											@RETURN_RESULT OUTPUT

	   IF @RETURN_RESULT = 0
	    RETURN


		/* FIND LAST INDEX OF SEPARATOR OF COMPLEX PROPERTIES IN THE COLLECTION */
		SELECT
			@JSON_OBJECT_COMPLEX_PROPERTIES_SEPARATOR_LAST_INDEX = MAX(JTC.ID)
		FROM #JSON_OBJECT_LAYOUT_TABLE_COLLECTION AS JTC
		WHERE JTC.TABLE_NAME = @SEPARATOR




		/* [ CORE PROCESSING - PART 7 ] DISTRIBUTE EACH RECORD TO APPROPRIATE TABLE
		
			LOOP MANAGER ( #NUMBER_OF_PROPERTIES_PER_EACH_OBJECT AS LOOP_MANAGER ) RUNS ITS OWN LOOP IN ASC ORDER,
			SO #JSON_ITEM_COLLECTION_TO_TABLE_INTERNAL_3 TABLE MUST CONFORM TO THIS ORDER IN THE CONTEXT OF EVERY MAIN JSON OBJECT COMPLEX PROPERTIES ORDER.
			CONTRARY TO THIS, ORDER OF MAIN JSON OBJECTS IN THE COLLECTION DOES NOT MATTER.		

		*/
		SET @INDEX_START_POSITION = 1		
		SET @TABLE_NAME = N''
		SET @PROPERTY_VALUE = N''

		DECLARE
			@OBJECT_NUMBER AS INT = -1,
			@OBJECT_NUMBER_PREV AS INT = -1,
			@CURRENT_OBJECT_PROPERTY_INDEX AS INT = -1,

			@REPLACE_RESULT AS NVARCHAR(MAX) = N'',

			@JSON_CONFIGURATION_TABLE_LIST_COUNT AS INT = -1,
			@JSON_CONFIGURATION_TABLE_LIST_CURRENT_INDEX AS INT = 1,
			@JSON_CONFIGURATION_TABLE_LIST_CURRENT_INDEX_CHANGE_DETERMINER AS INT = -1,
			@JSON_CONFIGURATION_TABLE_LIST_CURRENT_TABLE_NAME AS NVARCHAR(MAX) = N''


		/* DETERMINE NUMBER OF TABLES CONSTITUTING MAIN JSON OBJECT */
		SELECT
			@JSON_CONFIGURATION_TABLE_LIST_COUNT = MAX(NOPPEO_2.ID)
		FROM #NUMBER_OF_PROPERTIES_PER_EACH_OBJECT AS NOPPEO_2
										

		/* DETERMINE NUMBER OF PROPERTIES & NAME OF THE ROOT TABLE */
		SELECT
			@JSON_CONFIGURATION_TABLE_LIST_CURRENT_INDEX_CHANGE_DETERMINER = LOOP_MANAGER.NUMBER_OF_PROPERTIES,
			@JSON_CONFIGURATION_TABLE_LIST_CURRENT_TABLE_NAME = LOOP_MANAGER.TABLE_NAME
		FROM #NUMBER_OF_PROPERTIES_PER_EACH_OBJECT AS LOOP_MANAGER
		WHERE LOOP_MANAGER.ID = @JSON_CONFIGURATION_TABLE_LIST_CURRENT_INDEX

		/* EXECUTE LOOP */
		WHILE @INDEX_START_POSITION <= @INDEX_END_POSITION
		 BEGIN
			--IF WE PROCESSED LAST PROPERTY OF THE CURRENT OBJECT, INSERT INTO CONNECTED TABLES OBJECT'S STATE
			IF @OBJECT_NUMBER <> -1 AND @OBJECT_NUMBER_PREV <> -1 AND @OBJECT_NUMBER <> @OBJECT_NUMBER_PREV
			 BEGIN
				EXECUTE dbo.JSON2SQL_9_DO_BULK_INSERT
											@REPLACE_RESULT,
											@VALIDATION_INDEX_START,
											@VALIDATION_INDEX_END,
											@SEPARATOR,
											0,
											DEFAULT,
											DEFAULT,
											DEFAULT
			 END
			--WE'VE REACHED THE LAST PROPERTY OF THE LAST OBJECT IN THE COLLECTION
			ELSE IF @OBJECT_NUMBER <> -1 AND @OBJECT_NUMBER_PREV <> -1 AND @INDEX_START_POSITION = @INDEX_END_POSITION
			 BEGIN
				EXECUTE dbo.JSON2SQL_9_DO_BULK_INSERT
											@REPLACE_RESULT,
											@VALIDATION_INDEX_START,
											@VALIDATION_INDEX_END,
											@SEPARATOR,
											1,
											@NULL_CONSTANT,
											@INDEX_START_POSITION,
											@JSON_CONFIGURATION_TABLE_LIST_CURRENT_TABLE_NAME
			 END


			--THIS TAKES PLACE IMMEDIATELY AFTER WE'VE REACHED THE END OF THE COLLECTION
			IF @INDEX_START_POSITION > @INDEX_END_POSITION
			 CONTINUE


			--OTHERWISE STORE PREVIOUS OBJECT NUMBER AND APPLY FURTHER PROCESSING
		    SET @OBJECT_NUMBER_PREV = @OBJECT_NUMBER


			SELECT
				@OBJECT_NUMBER = JICTTI_3.OBJECT_NUMBER,
				@PROPERTY_VALUE = ISNULL(JICTTI_3.PROPERTY_VALUE, @NULL_CONSTANT),
				@CURRENT_OBJECT_PROPERTY_INDEX = JICTTI_3.CURRENT_OBJECT_PROPERTY_INDEX
			FROM #JSON_ITEM_COLLECTION_TO_TABLE_INTERNAL_3 AS JICTTI_3
			WHERE JICTTI_3.ID = @INDEX_START_POSITION


			--CHECK IF THIS IS THE FIRST PROPERTY OF NEXT OBJECT IN THE COLLECTION
			IF @OBJECT_NUMBER_PREV <> -1 AND @OBJECT_NUMBER <> -1 AND @OBJECT_NUMBER_PREV <> @OBJECT_NUMBER
			 BEGIN
				CONTINUE --GO TO PERFORMING ACTUAL INSERT OPERATION
			 END
			   

			SELECT
				@REPLACE_RESULT = dbo.DO_REPLACE(JTC.INSERT_SELECT_DATA_ROW, '{_________________$' + CAST(@CURRENT_OBJECT_PROPERTY_INDEX AS VARCHAR(MAX)) + '}', ''''+ @PROPERTY_VALUE + '''')
			FROM #JSON_OBJECT_LAYOUT_TABLE_COLLECTION AS JTC
			WHERE JTC.TABLE_NAME = @JSON_CONFIGURATION_TABLE_LIST_CURRENT_TABLE_NAME


			UPDATE JTC
				SET
					JTC.INSERT_SELECT_DATA_ROW = @REPLACE_RESULT
			FROM #JSON_OBJECT_LAYOUT_TABLE_COLLECTION AS JTC
			WHERE JTC.TABLE_NAME = @JSON_CONFIGURATION_TABLE_LIST_CURRENT_TABLE_NAME
			

			SET @JSON_CONFIGURATION_TABLE_LIST_CURRENT_INDEX_CHANGE_DETERMINER -= 1
			IF @JSON_CONFIGURATION_TABLE_LIST_CURRENT_INDEX_CHANGE_DETERMINER = 0
			 BEGIN
				--MOVE INDEX TO THE NEXT CHILD TABLE ...
				SET @JSON_CONFIGURATION_TABLE_LIST_CURRENT_INDEX += 1

				-- ... AND SUBSEQUENTLY CHECK IF WE ARE OUT OF RANGE, WHICH MEANS WE SHOULD MOVE INDEX BACK TO THE BEGINING, BECAUSE WE ARE ABOUT TO PROCESS NEXT MAIN OBJECT
				IF @JSON_CONFIGURATION_TABLE_LIST_CURRENT_INDEX > @JSON_CONFIGURATION_TABLE_LIST_COUNT
				 SET @JSON_CONFIGURATION_TABLE_LIST_CURRENT_INDEX = 1

				--DETERMINE NUMBER OF PROPERTIES & NAME OF THE NEXT CHILD TABLE
				SELECT
					@JSON_CONFIGURATION_TABLE_LIST_CURRENT_INDEX_CHANGE_DETERMINER = NOPPEO_2.NUMBER_OF_PROPERTIES,
					@JSON_CONFIGURATION_TABLE_LIST_CURRENT_TABLE_NAME = NOPPEO_2.TABLE_NAME
				FROM #NUMBER_OF_PROPERTIES_PER_EACH_OBJECT AS NOPPEO_2
				WHERE NOPPEO_2.ID = @JSON_CONFIGURATION_TABLE_LIST_CURRENT_INDEX
			 END

			SET @REPLACE_RESULT = N''

		  SET @INDEX_START_POSITION += 1
		 END
END