==========================================================================================================================================================================================
THIS MANUAL REFERS TO 
					  CONVERT_JSON_OBJECT_TO_SQL_TABLE_4_P [v4]
																VERSION OF JSON2SQL
==========================================================================================================================================================================================

==========================================================================================================================================================================================
 AUTOMATIC INSTALLATION		||
 AUTOMATIC UNINSTALLATION	||

 IN ORDER TO USE [runControlPanelMgr.bat] PROVIDED IN THE [SolutionNavigator] SOLUTION FOLDER,
 PLEASE GO TO [SolutionNavigator]/[runControlPanelMgrInfo.txt] FILE FOR MORE DETAILS ON WHAT OPTIONS TO USE.
 PLEASE VISIT [CONTROL PANEL v1] SECTION.


 SSMS [runControlPanelMgr.bat] integration:

	Please devote time to watching short 4 videos on how to set up [runControlPanelMgr.bat] integration in SSMS.
	You can access these videos under root folder of repository  [
																	runControlPanelMgr___set_up_part_1.mp4,
																	runControlPanelMgr___set_up_part_2.mp4,
																	runControlPanelMgr___set_up_part_3.mp4,
																	runControlPanelMgr___set_up_part_4.mp4
																 ]
	due to GitHub's maximum file upload size <= 25MB requirement. 

==========================================================================================================================================================================================


==========================================================================================================================================================================================


==========================================================================================================================================================================================
 MANUAL INSTALLATION		||
							||

	1. RUN [T-SQL_UTILITY_FUNCTIONS_INSTALL.sql]

	2. RUN [JSON2SQL_T-SQL_UTILITY_PROCEDURES_INSTALL.sql]

	3. RUN [CONVERT_JSON_OBJECT_TO_SQL_TABLE_4_P [v4].sql]



 MANUAL UNINSTALLATION		||
							||

	1. RUN [T-SQL_UTILITY_FUNCTIONS_UNINSTALL.sql]

	2. RUN [JSON2SQL_T-SQL_UTILITY_PROCEDURES_UNINSTALL.sql]
==========================================================================================================================================================================================


==========================================================================================================================================================================================


==========================================================================================================================================================================================
 TESTING OF VERSIONS		||
							||

	===========================================================
	v1.0.0 [CONVERT_JSON_OBJECT_TO_SQL_TABLE [v1]]
	===========================================================

	EXAMLES ARE PROVIDED IN THE FOLDER:  ..\TESTS\v1.0.0 [v1]
	
========================================================================================================================================================================================


	===========================================================
	v1.1.0 [CONVERT_JSON_OBJECT_TO_SQL_TABLE_2_P [v2]]
	===========================================================

	EXAMLES ARE PROVIDED IN THE FOLDER:  ..\TESTS\v1.1.0 [v2]
	
========================================================================================================================================================================================


	===========================================================
	v1.5.0 [CONVERT_JSON_OBJECT_TO_SQL_TABLE_3_P [v3]]
	===========================================================

	EXAMLES ARE PROVIDED IN THE FOLDER:  ..\TESTS\v1.5.0 [v3]
	
========================================================================================================================================================================================


	==========================================================
	v1.8.0 [CONVERT_JSON_OBJECT_TO_SQL_TABLE_4_P [v4]]
	==========================================================

	EXAMLES ARE PROVIDED IN THE FOLDER:  ..\TESTS\v1.8.0 [v4]


========================================================================================================================================================================================







==================									   ===================================                                       ===============================                   =====
                     =====================                       =============================                           ====================                             ==============






==========================================================================================================================================================================================
 Input parameters explanation [version v1.5.0+]
==========================================================================================================================================================================================
 ______________________________________________________________________________________________________________________________________________________________________________________
|																																													   |
|																																													   | 
| ALL THE ABOVE CASES ARE PROVIDED WITH SAMPLES IN THIS SOLUTION. LOOK INTO FOLDER CALLED testing.																					   |
|																																													   |
|	::[ @P_JSON_COLLECTION_OBJECT_LAYOUT ]::																																		   |
|		FIRST INPUT PARAMETER REFLECTS SINGLE MAIN JSON OBJECT, i.e. in the provided samples such main object consists of max. 3 complex properties.								   |
|		Each complex property is separated from another by using |																													   |
|																																													   |
|										'MY_ROOT_TABLE, -- this table reflects properties of main object																			   |
|										 MY_SUB_TABLE_1_1,MY_SUB_TABLE_1_2,MY_SUB_TABLE_1_3, -- these tables reflect properties of first complex object under main object		       |
|										  (MY_SUB_TABLE_1_1 -> nesting level 2) (MY_SUB_TABLE_1_2 -> nesting level 3) (MY_SUB_TABLE_1_4 -> nesting level 4)                            |
|																																													   |
|										 |, -- this is separator of complex properties																								   |
|																																													   |
|										 MY_SUB_TABLE_2_1,MY_SUB_TABLE_2_2,MY_SUB_TABLE_2_3, --these tables reflect properties of second complex object under main object              |
|										  (MY_SUB_TABLE_2_1 -> nesting level 2) (MY_SUB_TABLE_2_2 -> nesting level 3) (MY_SUB_TABLE_2_3 -> nesting level 4)                            |
|																																													   |
|										 |, -- this is separator of complex properties																								   |
|																																													   |
|										 MY_SUB_TABLE_3_1,MY_SUB_TABLE_3_2,MY_SUB_TABLE_3_3, --these tables reflect properties of third complex object under main object	           |
|										  (MY_SUB_TABLE_3_1 -> nesting level 2) (MY_SUB_TABLE_3_2 -> nesting level 3) (MY_SUB_TABLE_3_3 -> nesting level 4)                            |
|																																													   |
|										 |, -- this is separator of complex properties																								   |
|																																													   | 
|										 MY_SUB_TABLE_4_1,MY_SUB_TABLE_4_2,MY_SUB_TABLE_4_3 --these tables reflect properties of fourth complex object under main object               |
|										  (MY_SUB_TABLE_4_1 -> nesting level 2) (MY_SUB_TABLE_4_2 -> nesting level 3) (MY_SUB_TABLE_4_3 -> nesting level 4)                            |
|																																													   |
|	::[ @P_JSON_COLLECTION ]::																																						   |
|		SECOND INPUT PARAMETER IS JSON COLLCTION																																	   |
|																																													   |
|______________________________________________________________________________________________________________________________________________________________________________________|