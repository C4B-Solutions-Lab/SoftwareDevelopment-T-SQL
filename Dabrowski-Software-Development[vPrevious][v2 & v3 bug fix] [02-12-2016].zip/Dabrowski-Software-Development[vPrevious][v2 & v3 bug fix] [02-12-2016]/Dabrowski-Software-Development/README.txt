==========================================================================================================================================================================================
 INSTALLATION
	
	1. RUN T-SQL UTILITY FUNCTIONS.sql

	2. RUN T-SQL UTILITY PROCEDURES.sql

	3. RUN CONVERT_JSON_OBJECT_TO_SQL_TABLE_2_P [v2].sql OR CONVERT_JSON_OBJECT_TO_SQL_TABLE_3_P [v3].sql


 NOTES:
	
	1. PLEASE TAKE INTO ACCOUNT THAT ALL MODIFICATIONS (UPDATE) APPLY TO CONVERT_JSON_OBJECT_TO_SQL_TABLE_2_P [v2] OR CONVERT_JSON_OBJECT_TO_SQL_TABLE_3_P [v3].
	   PROCEDURE CONVERT_JSON_OBJECT_TO_SQL_TABLE [v1] STAYS THE SAME WITH MINOR ENHANCEMENTS TO STRING LITERALS.

	2. PLEASE TAKE INTO ACCOUNT THAT ALL PROCEDURES MARKED WITH [DEPRECATED] SUFFIX ARE THE PREVIOUS BUGGY VERSIONS OF THE BEFORE MENTIONED PROCEDURES,
	   THEREFORE WILL BE REMOVED IN THE NEXT RELEASE.
	

==========================================================================================================================================================================================


==========================================================================================================================================================================================
 TESTING OF VERSIONS
==========================================================================================================================================================================================

	===========================================================
	v1.1.0 [CONVERT_JSON_OBJECT_TO_SQL_TABLE_2_P [v2]]
	===========================================================

	EXAMLES ARE PROVIDED IN THE FOLDER:  ..\TESTS\v1.1.0 [v2]
	
========================================================================================================================================================================================


	===========================================================
	v1.5.0 [CONVERT_JSON_OBJECT_TO_SQL_TABLE_3_P [v3]]
	===========================================================

	EXAMLES ARE PROVIDED IN THE FOLDER:  ..\TESTS\v1.5.0 [v3]
	
========================================================================================================================================================================================


	==========================================================
	v1.8.0 [CONVERT_JSON_OBJECT_TO_SQL_TABLE_4_P [v4]]
	==========================================================

	EXAMLES ARE PROVIDED IN THE FOLDER:  ..\TESTS\v1.8.0 [v4]


========================================================================================================================================================================================







==================									   ===================================                                       ===============================                   =====
                     =====================                       =============================                           ====================                             ==============






==========================================================================================================================================================================================
 Input parameters explanation [version v1.5.0+]
==========================================================================================================================================================================================
 ______________________________________________________________________________________________________________________________________________________________________________________
|																																													   |
|																																													   | 
| ALL THE ABOVE CASES ARE PROVIDED WITH SAMPLES IN THIS SOLUTION. LOOK INTO FOLDER CALLED testing.																					   |
|																																													   |
|	::[ @P_JSON_COLLECTION_OBJECT_LAYOUT ]::																																		   |
|		FIRST INPUT PARAMETER REFLECTS SINGLE MAIN JSON OBJECT, i.e. in the provided samples such main object consists of max. 3 complex properties.								   |
|		Each complex property is separated from another by using |																													   |
|																																													   |
|										'#MY_ROOT_TABLE, -- this table reflects properties of main object																			   |
|										 #MY_SUB_TABLE,#MY_SUB_SUB_TABLE,#MY_SUB_SUB_SUB_TABLE, -- these tables reflect properties of first complex object under main object		   |
|										  (#MY_SUB_TABLE -> nesting level 2) (#MY_SUB_SUB_TABLE -> nesting level 3) (#MY_SUB_SUB_SUB_TABLE -> nesting level 4)                         |
|																																													   |
|										 |, -- this is separator of complex properties																								   |
|																																													   |
|										 #2_MY_SUB_TABLE,#2_MY_SUB_SUB_TABLE,#2_MY_SUB_SUB_SUB_TABLE, --these tables reflect properties of second complex object under main object     |
|										  (#2_MY_SUB_TABLE -> nesting level 2) (#2_MY_SUB_SUB_TABLE -> nesting level 3) (#2_MY_SUB_SUB_SUB_TABLE -> nesting level 4)                   |
|																																													   |
|										 |, -- this is separator of complex properties																								   |
|																																													   |
|										 #3_MY_SUB_TABLE,#3_MY_SUB_SUB_TABLE,#3_MY_SUB_SUB_SUB_TABLE, --these tables reflect properties of third complex object under main object	   |
|										  (#3_MY_SUB_TABLE -> nesting level 2) (#3_MY_SUB_SUB_TABLE -> nesting level 3) (#3_MY_SUB_SUB_SUB_TABLE -> nesting level 4)                   |
|																																													   |
|										 |, -- this is separator of complex properties																								   |
|																																													   | 
|										 #4_MY_SUB_TABLE,#4_MY_SUB_SUB_TABLE,#4_MY_SUB_SUB_SUB_TABLE --these tables reflect properties of fourth complex object under main object      |
|										  (#4_MY_SUB_TABLE -> nesting level 2) (#4_MY_SUB_SUB_TABLE -> nesting level 3) (#4_MY_SUB_SUB_SUB_TABLE -> nesting level 4)                   |
|																																													   |
|	::[ @P_JSON_COLLECTION ]::																																							   |
|		SECOND INPUT PARAMETER IS JSON COLLCTION																																	   |
|																																													   |
|______________________________________________________________________________________________________________________________________________________________________________________|